How to set up DCI Reporter v3:

If you have already installed a previous version of DCI Reporter, go into the control panel of windows, and use the Add/Remove program feature. Remove the preiously installed version of DCI Reporter V3.
Run the Setup.exe application and proceed to the installation.

If you do not already have done so, download the latest PIN database from the TO download center. Once downloaded and unzipped, copy the PIN database in the folder C:\DCIReporterUSer

If you do not have access to all the games and format, download the latest DCI Reporter V3 update from the TO web site. Once downloaded and unzipped, copy all the update files in C:\DCIReporterUSer. 



Known Install Issues:

- If you are using Windows XP and do not have applied Service Pack 2 you will need to get a Microsoft Data Access Component resource at 
http://www.microsoft.com/downloads/details.aspx?DisplayLang=en&FamilyID=6c050fe3-c795-4b7d-b037-185d0506396c

---------------------
V1.1 bug fixes list
---------------------
Fixed issues with events entered after event took place
- Selection of this type of input is done with the game format (remember this is not supported for team events)
- Fixed issues with number of rounds
- It is now possible to save the input before it is finished, so that keying does not have to be all done before closing the window

Drop Shortcuts are ALT-R and Alt-D to account for non qwerty keyboards key settings.



---------------------
V1.0.16 bug fixes list
---------------------
Random pairing fixed: it now does random pairing of the top X players in the standings, and not the top X registered players.
Drop shortcuts are ALT-A and ALT-Z instead of Alt-A and Alt-B


---------------------
V1.0.15 bug fixes list
---------------------
Copy to clipboard supported for data displayed in grid

Fixed error when opening local player database with no open event

Side events fees now allows Decimal

Side Event player registration now allows to check player's name after converting the dci number

Dreamblade third tiebreaker (OOMW%) fixed

Side events make file generation fixed.

Fixed a bug involving ordered pairing and more than one player dropped during the same round

Seat All saved file is no longer deleted. It is kept until the next save is done.


---------------------
V1.0.12 bug fixes list
---------------------
Fixed Timestamp issues

Simplified region/zip code validation on tournament setup.

Simplified setup: added shortcut to DCIreporterUser folder in the installation folder.

Added F12 as shortcut to Look up player data

Fixed issue when creating a single elim or double elim event.

F3 result entry: Fixing result entry through Quickkeys

F3 result entry: Drop shortcut changed to A and B

Fixed a bug where manual pairings during playoff where not saved properly after being updated.


---------------------
V1.0.9 bug fixes list
---------------------

DCI Electronic Reporting screen: If an error is raised during Make File XML generation is the generated file so far preserved in order to make it easier to identify problems.

DCI Electronic Reporting screen: An Array error message would sometimes be generated if the event was not closed and re-opened before hitting MakeFile or Internet Upload. This is fixed

All time stamps have been changed to local time. This should fix most of the time stamp issues, the other ones being linked to a possible bad local time settings.

Perform Pairing: If provisional standings were the latest standings computed at the moment F7 was hit, those provisionla standings were used for the next paring. This is fixed.

The default path for the round clock .wav files has been changed to Application.StartupPath

Printouts: A few reports did not include EventName in the header.

Printing: Error trapping added to catch printer errors, especially exceptions raised by remote printer services. On a SQL Server, a RPC exception may be raised without any cause; when the exception is thrown there is nothing else to do than acting upon it.

F3: Increasing the number of draws was not possible for results 2-1 / 2-0 / 1-2 / 0-2 while having hotkeys enabled.

F3: Hitting TAB while focus is on the Table textbox now moves the cursor to the first results entry textbox.

Penalties screen: A number of updates fixing refresh, loading and saving.

Local Players: Crash if all players were selected and then deleted.

Local Players: A warning message is being displayed if the user tries to select a player while no event is open.

Local Players: Some old DCI Reporter files with 12 variable fields are still around. The input validation now accepts this format.

Local Players: Loading a new file of players did not refresh the grid properly.

F2, Change Enrolled: A valid 8-digit pin was not auto converted.

Event Creation: Selecting an elimination pairing method would hide the entire Pairing Method groupbox.

Print Certificate: The certificate was printed for another player than the selected one.

Print pairings by table and player: Playoff rounds could not be selected.


