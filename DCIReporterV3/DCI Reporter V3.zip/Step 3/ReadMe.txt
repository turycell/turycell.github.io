Installation process.
---------------------
Close any occurence of DCI reporter v3 that would be currently running on your machine.

Copy the following files in your C:\DCIReporterUser folder
ReporterUser.txt
Prizes.txt
Stature.txt
Penalties.txt
*Replace any of these already existing file if you are prompted to do so*

Start DCI Reporter v3 to get access to the Advanced Edition functions

Advanced Edition information
---------------------------
This version allows you to have access to the following features:
- Pre Registrations
- Keeping multiple local player databases
- Cut (ability to cut to the X top players for a Day 2)
- Multi Format (ability to run one event with more than one format. Note: event needs to have been sanctioned as such)
- Playoff (single elimination playoffs)

Important Notes about DCI Reporter v3
-------------------------------------
- DCI Reporter v3 file format is not compatible with DCI Reporter 2.9.25 and earlier versions.
- DCI Reporter v3 uses Microsoft .Net Framework
- DCI Reporter v3 parameters file are txt based, but should not be modified by non WOTC staff. Doing so may cause issues in using v3 and when uploading files.
- Multi language support is available for DCI Reporter v3. Check the DCI download pages or contact your DCI representative to get access to the localized files.
- Network support relies on TCPIP, and allows to do registrations as well as results reporting over multiple machines.
